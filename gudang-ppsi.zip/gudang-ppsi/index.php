<?php
// alihkan ke halaman login
header('location: login.php');
